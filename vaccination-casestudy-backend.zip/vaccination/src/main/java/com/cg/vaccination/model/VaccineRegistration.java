package com.cg.vaccination.model;



import javax.persistence.Entity; 

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class VaccineRegistration {

	@Id
	private long mobileNo;
	private String password;
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public VaccineRegistration(long mobileNo, String password) {
		super();
		this.mobileNo = mobileNo;
		this.password = password;
	}
	public VaccineRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "VaccineRegistration [mobileNo=" + mobileNo + ", password=" + password + "]";
	}

	
	

}
