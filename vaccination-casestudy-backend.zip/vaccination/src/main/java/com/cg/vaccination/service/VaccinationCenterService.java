package com.cg.vaccination.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.vaccination.model.VaccinationCenter;

@Service
public interface VaccinationCenterService {
	public List<VaccinationCenter> allVaccineCenters();

	public VaccinationCenter addVaccinationCenter(VaccinationCenter vaccinationcenter);

	public Optional<VaccinationCenter> getVaccinationCenterbyId(int centerid);

	public VaccinationCenter updateVaccinationCenter(VaccinationCenter vaccinationcenter);

	public void deleteVaccinationCenter(VaccinationCenter vaccinationCenter);

	public Optional<VaccinationCenter> getVaccinationCenterbyPincode(String pincode);

}
