package com.cg.vaccination.controller;

import java.util.HashMap; 
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.vaccination.exception.VaccinationCenterNotFoundException;
import com.cg.vaccination.model.VaccinationCenter;
import com.cg.vaccination.service.VaccinationCenterService;

@RestController
@CrossOrigin (origins = "http://localhost:4200")
@RequestMapping("/vaccinationcenter")
public class VaccinationCenterController {

	@Autowired
	private VaccinationCenterService centerService;

	@GetMapping("/all")
	public List<VaccinationCenter> allVaccinationCenter() {
		return centerService.allVaccineCenters();
	}

	@PostMapping("/add")
	public VaccinationCenter addVaccinationCenter(@RequestBody VaccinationCenter vaccinationCenter) {
		return centerService.addVaccinationCenter(vaccinationCenter);
	}

	@GetMapping("/getbyid/{id}")
	public ResponseEntity<VaccinationCenter> getVaccinationCenterById(@PathVariable(value = "id") int centerid)
			throws VaccinationCenterNotFoundException {
		VaccinationCenter vaccinationCenter = centerService.getVaccinationCenterbyId(centerid).orElseThrow(
				() -> new VaccinationCenterNotFoundException("No Vaccination Center found with id :  " + centerid));
		return ResponseEntity.ok().body(vaccinationCenter);
	}

	@PutMapping("/updatebyid/{id}")
	public ResponseEntity<VaccinationCenter> updateVaccinationCenter(@PathVariable(value = "id") int centerid,
			@RequestBody VaccinationCenter centerDetails) throws VaccinationCenterNotFoundException {
		VaccinationCenter vaccinationCenter = centerService.getVaccinationCenterbyId(centerid).orElseThrow(
				() -> new VaccinationCenterNotFoundException("No Vaccination Center found with id :  " + centerid));
		vaccinationCenter.setCentername(centerDetails.getCentername());
		vaccinationCenter.setAddress(centerDetails.getAddress());
		vaccinationCenter.setCity(centerDetails.getCity());
		vaccinationCenter.setState(centerDetails.getState());
		vaccinationCenter.setDistrict(centerDetails.getDistrict());
		vaccinationCenter.setPincode(centerDetails.getPincode());
		VaccinationCenter updatedCenter = centerService.updateVaccinationCenter(vaccinationCenter);
		return ResponseEntity.ok(updatedCenter); // Response entity means sending respons with data and status
	}
	
	@GetMapping("/getbypincode/{pin}")
	public ResponseEntity<VaccinationCenter> getVaccinationCenterByPinCode(@PathVariable(value = "pin") String pincode)
			throws VaccinationCenterNotFoundException {
		VaccinationCenter vaccinationCenter = centerService.getVaccinationCenterbyPincode(pincode).orElseThrow(
				() -> new VaccinationCenterNotFoundException("No Vaccination Center found with Pincode Of :  " + pincode));
		return ResponseEntity.ok().body(vaccinationCenter);
	}

	@DeleteMapping("/delete/{id}")
	public Map<String, Boolean> deleteVaccinationCenter(@PathVariable(value = "id") int centerid)
			throws VaccinationCenterNotFoundException {
		VaccinationCenter vaccinationCenter = centerService.getVaccinationCenterbyId(centerid).orElseThrow(
				() -> new VaccinationCenterNotFoundException("No Vaccination Center found with id :  " + centerid));
		centerService.deleteVaccinationCenter(vaccinationCenter);
		Map<String, Boolean> response = new HashMap<>();
		response.put("Delete", Boolean.TRUE);
		return response;

	}

}
