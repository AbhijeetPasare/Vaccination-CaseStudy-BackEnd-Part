package com.cg.vaccination.exception;
public class AppointmentNotFoundException extends Exception {
public AppointmentNotFoundException() {}
public AppointmentNotFoundException(String message) {
	super(message);
}
}
