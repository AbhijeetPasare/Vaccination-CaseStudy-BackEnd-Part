package com.cg.vaccination.exception;

public class VaccineRegistrationNotFoundException extends Exception {

	public VaccineRegistrationNotFoundException() {

	}

	public VaccineRegistrationNotFoundException(String message) {
		super(message);
	}

}
