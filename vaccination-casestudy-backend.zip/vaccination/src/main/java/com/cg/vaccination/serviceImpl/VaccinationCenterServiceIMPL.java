package com.cg.vaccination.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.vaccination.model.VaccinationCenter;
import com.cg.vaccination.repository.VaccinationCenterRepository;
import com.cg.vaccination.service.VaccinationCenterService;

@Service
public class VaccinationCenterServiceIMPL implements VaccinationCenterService {

	@Autowired
	private VaccinationCenterRepository centerRepository;

	@Override
	public List<VaccinationCenter> allVaccineCenters() {
		// TODO Auto-generated method stub
		return centerRepository.findAll();
	}

	@Override
	public VaccinationCenter addVaccinationCenter(VaccinationCenter vaccinationcenter) {
		// TODO Auto-generated method stub
		return centerRepository.save(vaccinationcenter);
	}

	@Override
	public VaccinationCenter updateVaccinationCenter(VaccinationCenter vaccinationcenter) {
		// TODO Auto-generated method stub
		return centerRepository.save(vaccinationcenter);
	}

	@Override
	public void deleteVaccinationCenter(VaccinationCenter vaccinationCenter) {
		// TODO Auto-generated method stub
		centerRepository.delete(vaccinationCenter);
	}

	@Override
	public Optional<VaccinationCenter> getVaccinationCenterbyId(int centerid) {
		// TODO Auto-generated method stub
		return centerRepository.findById(centerid);
	}

	@Override
	public Optional<VaccinationCenter> getVaccinationCenterbyPincode(String pincode) {
		// TODO Auto-generated method stub
		return centerRepository.getByPincode(pincode);
	}

}
