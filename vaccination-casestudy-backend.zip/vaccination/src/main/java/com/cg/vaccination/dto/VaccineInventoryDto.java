package com.cg.vaccination.dto;

import java.time.LocalDate;

public class VaccineInventoryDto {

	private int id;
	private int quantity;
	private double price;
	private LocalDate date;
	private int centerCode;
    private int vaccineId;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public int getCenterCode() {
		return centerCode;
	}
	public void setCenterCode(int centerCode) {
		this.centerCode = centerCode;
	}
	public int getVaccineId() {
		return vaccineId;
	}
	public void setVaccineId(int vaccineId) {
		this.vaccineId = vaccineId;
	}
	public VaccineInventoryDto(int id, int quantity, double price, LocalDate date, int centerCode, int vaccineId) {
		super();
		this.id = id;
		this.quantity = quantity;
		this.price = price;
		this.date = date;
		this.centerCode = centerCode;
		this.vaccineId = vaccineId;
	}
	public VaccineInventoryDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "VaccineInventoryDto [id=" + id + ", quantity=" + quantity + ", price=" + price + ", date=" + date
				+ ", centerCode=" + centerCode + ", vaccineId=" + vaccineId + "]";
	}
    
    
	
}
