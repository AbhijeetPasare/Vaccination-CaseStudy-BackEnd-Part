package com.cg.vaccination.model;

import javax.persistence.Column;  
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class VaccinationCenter {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "center_code")
	private int code;
	private String centername;
	private String address;
	private String city;
	private String state;
	private String district;
	private String pincode;
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getCentername() {
		return centername;
	}
	public void setCentername(String centername) {
		this.centername = centername;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getPincode() {
		return pincode;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public VaccinationCenter(int code, String centername, String address, String city, String state, String district,
			String pincode) {
		super();
		this.code = code;
		this.centername = centername;
		this.address = address;
		this.city = city;
		this.state = state;
		this.district = district;
		this.pincode = pincode;
	}
	public VaccinationCenter() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "VaccinationCenter [code=" + code + ", centername=" + centername + ", address=" + address + ", city="
				+ city + ", state=" + state + ", district=" + district + ", pincode=" + pincode + "]";
	}

	

}
