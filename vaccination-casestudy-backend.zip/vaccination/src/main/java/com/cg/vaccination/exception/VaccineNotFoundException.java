package com.cg.vaccination.exception;

public class VaccineNotFoundException extends Exception {

	public VaccineNotFoundException() {

	}

	public VaccineNotFoundException(String message) {
		super(message);
	}
}
