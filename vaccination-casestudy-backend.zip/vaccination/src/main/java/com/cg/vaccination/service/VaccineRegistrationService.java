package com.cg.vaccination.service;




import com.cg.vaccination.model.VaccineRegistration;

public interface VaccineRegistrationService {


	
	public VaccineRegistration addVaccineRegistration(VaccineRegistration reg);

    
}
