package com.cg.vaccination.dto;

import java.time.LocalDate; 

import javax.persistence.CascadeType;
import javax.persistence.EnumType;

import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

public class AppointmentDto {
	private long bookingId;
	private long mobileNo;
	private LocalDate dateOfBooking;
    private int centerCode;
    private int  memberIdCard;
	private String slot;
	public long getBookingId() {
		return bookingId;
	}
	public void setBookingId(long bookingId) {
		this.bookingId = bookingId;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public LocalDate getDateOfBooking() {
		return dateOfBooking;
	}
	public void setDateOfBooking(LocalDate dateOfBooking) {
		this.dateOfBooking = dateOfBooking;
	}
	public int getCenterCode() {
		return centerCode;
	}
	public void setCenterCode(int centerCode) {
		this.centerCode = centerCode;
	}
	public int getMemberIdCard() {
		return memberIdCard;
	}
	public void setMemberIdCard(int memberIdCard) {
		this.memberIdCard = memberIdCard;
	}
	public String getSlot() {
		return slot;
	}
	public void setSlot(String slot) {
		this.slot = slot;
	}
	public AppointmentDto(long bookingId, long mobileNo, LocalDate dateOfBooking, int centerCode, int memberIdCard,
			String slot) {
		super();
		this.bookingId = bookingId;
		this.mobileNo = mobileNo;
		this.dateOfBooking = dateOfBooking;
		this.centerCode = centerCode;
		this.memberIdCard = memberIdCard;
		this.slot = slot;
	}
	public AppointmentDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "AppointmentDto [bookingId=" + bookingId + ", mobileNo=" + mobileNo + ", dateOfBooking=" + dateOfBooking
				+ ", centerCode=" + centerCode + ", memberIdCard=" + memberIdCard + ", slot=" + slot + "]";
	}
	

}

