package com.cg.vaccination.exception;

public class MemberStatusNotFoundException extends Exception {
public MemberStatusNotFoundException() {}
public MemberStatusNotFoundException(String message) {
	super(message);
}
}
